<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Form</title>
  </head>
   <?php
   // Database connection
   $server ="localhost";
   $username = "root";
   $password = "";
   $dbname="task";
   $conn = mysqli_connect($server,$username,$password,$dbname);

   // validate captcha 
   if(isset($_POST['submit']) && $_POST['g-recaptcha-response'] != ""){
       $secret_key ="6LcqR5ocAAAAAGnDhjVFXS4pZ8vNE1KiKK598fF4";
       $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response=' . $_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        $name = $_POST['name'];
        $email = $_POST['email'];
        $dob = $_POST['dob'];
        $about_me = $_POST['aboutme'];
        if ($responseData) {
             $query = mysqli_query($conn, "INSERT INTO user(name,email,dob,aboutme) VALUES('".$name."','".$email."','".$dob."','".$about_me."')");
            if($query){
                $msg =  "Your registration has been successfully done!";
            }else{
                $error = "Your registration not done ";
            }
        }
   }
        // timer 
      $time = 3;
      $dateFormat  = "d F Y -- g:i a";
      $targetDate  = time() + ($time*60);
      $actualDate  = time();
      $secondsDiff = $targetDate - $actualDate;
      $remainingDay      = floor($secondsDiff/60/60/24);
      $remainingHour     = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
      $remainingMinutes  = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
      $remainingSeconds  = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));
      $actualDateDisplay = date($dateFormat,$actualDate);
      $targetDateDisplay = date($dateFormat,$targetDate);
?>
  <body onLoad="setCountDown();">
    <div class="container">
        <form method="post" class="form-control mt-5" id="demo-form">

        <div class="mb-3 row" style="float: right;">
        <p id="remain">
         <?php echo "$remainingMinutes minutes, $remainingSeconds seconds";?>
        </p>
        </div>
        <br>
        <div class="mb-3 row text-center">
        <label class="col-sm-2 col-form-label"></label>
        <div class="col-sm-10">
            <h1 class="text-success">About me</h1>
        </div>
        </div>
        <?php 
        if(isset($msg)){
            echo '<div class="alert alert-success alert-dismissible fade show text-center" role="alert">
                        '.$msg.'
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';
        }else if(isset($error)){
            echo '<div class="alert alert-warning alert-dismissible fade show text-center" role="alert">
            '.$error.'
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';
        }
        ?>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Enter your name" name="name">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
                <input type="text"  class="form-control" placeholder="Enter your mail id" name="email">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">DOB</label>
            <div class="col-sm-10">
                <input type="date"  class="form-control" name="dob">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">About </label>
            <div class="col-sm-10">
                <textarea class="form-control" rows="3" name="aboutme"></textarea>
            </div>
        </div>
        <div class="mb-3 row">
            <div class="col-sm-2 col-from-label"></div>
            <div class="col-sm-4">
                <p class="g-recaptcha" data-sitekey="6LcqR5ocAAAAAOIxqJR0zB4u2BgFGLmXthCKTcnb"></p>
            </div>
        </div>
        <div class="mb-3 text-center">
        <button class="btn btn-outline-primary" name="submit">Submit</button>
        </div>
        </form>
      </div>
      <script src="https://www.google.com/recaptcha/api.js"></script>
    <script>
   function onSubmit(token) {
     document.getElementById("demo-form").submit();
   }
 </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  </body>
  <script type="text/javascript">
      var days = <?php echo $remainingDay; ?>  
      var hours = <?php echo $remainingHour; ?>  
      var minutes = <?php echo $remainingMinutes; ?>  
      var seconds = <?php echo $remainingSeconds; ?> 
      function setCountDown ()
      {
          seconds--;
          if (seconds < 0){
             minutes--;
             seconds = 59
          }
          if (minutes < 0){
              hours--;
              minutes = 59
          }
          if (hours < 0){
              hours = 23
          }
          document.getElementById("remain").innerHTML = " Form will refresh in : "+minutes+" min    "+seconds+" sec";
          SD=window.setTimeout( "setCountDown()", 1000 );
          if (minutes == '00' && seconds == '00') { 
              seconds = "00"; window.clearTimeout(SD);
              window.location.reload();
          } 

       }
    </script>
</html>

